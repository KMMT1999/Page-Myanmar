from django.contrib import admin

# Register your models here.
from hr_jobs.models import JobModel

admin.site.register(JobModel)